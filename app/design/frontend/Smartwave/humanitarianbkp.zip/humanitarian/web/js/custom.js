require(['jquery', 'jquery/ui'], function($){
  jQuery(document).ready( function() {
  	jQuery(".donate-popup").click(function(){
                jQuery('body, html').animate({scrollTop:$('body').offset().top});
                jQuery(".pre").html('');
                $(this).addClass('active');
                var imgPath = $(this).attr('data-img');
                var sku = $(this).attr('data-sku');
                var productId = $(this).attr('data-id');
                var name = $(this).attr('data-name');
                var description = $(this).attr('data-description');
                var qty = $(this).attr('data-qty');
                jQuery(".hidden-id").val(productId);
                jQuery(".hidden-sku").val(sku);
                jQuery(".donation-box img").attr('src',imgPath);
                jQuery(".description").append('<span>'+description+'</span>');
                jQuery(".qty-needed").append('<span> Quantity Needed: '+qty+'</span>');
                jQuery(".product-name").append('<span>'+name+'</span>');
  		jQuery('.donation-popup-container').css({"display": "block","position": "absolute","width": "100%","height": "100%","background": "#00000030","top": "5px","left": "0","bottom": "5px", "right": "0","z-index": "11"});
  	});
  	jQuery(".donation-popup-container-close").click(function(){
  		jQuery('.donation-popup-container').hide();
  	});
  	jQuery(".donate-now").click(function(){
               var sku = $('.hidden-sku').val();
               var id = $('.hidden-id').val();
               var donatedBy = $("#donation-donated-by").val();
               var address = $("#donation-address").val()+" "+$("#donation-postcode").val();
               var donatedType = $("#donation-donated-type").val();
               var description = $("#donation-description").val();
               var qty = $("#donation-qty").val();
               var posturl = $(".donate-popup").attr('data-url');
  	$.ajax({
        url: posturl,
	      type: "POST",
        data: {'product_id':id, 'product_sku':sku,'description':description,'donated_by':donatedBy,'address':address,'donor_type':donatedType,'qty':qty},
	       success: function(){
                  //console.log(response.output);
                  jQuery('.donation-popup-container').hide();
                //jQuery(".donation-box").prepend(response.output.status);
	     },
         complete:function(){
            $('body, html').animate({scrollTop:$('body').offset().top}, 'slow');
        }
	    });

	    return false;
 	});
   });
});