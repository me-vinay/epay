require(["jquery", "jquery/ui"], function ($) {
    "use strict";
    jQuery(document).ready(function () {
        $(".process").on("click", function (event) {
            var url = $(this).attr("href");
            $.ajax({
                url: url,
                type: "POST",
                showLoader: true,
                success: function () {
                    // $(this).css({"pointer-events":"none", "cursor":"default"});
                    //$(this).attr("disabled", true);
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                },
                complete: function () {
                    $("body, html").animate({
                        scrollTop: $("body").offset().top,
                    });
                },
            });
            event.preventDefault();
        });

        $(".delete").click(function () {
            var url = $(this).attr("href");
            $.ajax({
                url: url,
                type: "POST",
                showLoader: true,
                success: function () {
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                },
                complete: function () {
                    $("body, html").animate({
                        scrollTop: $("body").offset().top,
                    });
                },
            });
        });
    });
});
