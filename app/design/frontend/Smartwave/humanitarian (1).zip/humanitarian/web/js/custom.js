require(['jquery', 'jquery/ui'], function($){
  jQuery(document).ready( function() {
  	jQuery(".donate-popup").click(function(){
                $('body').css('overflow','hidden');
                //jQuery(".content-box").show();
                //if($("response-msg").length){
                  jQuery(".donation-input").val('');
                  jQuery(".response-msg").remove();
                //}
                if($(".inactive").length){
                  $(".donate-now").removeClass('inactive');
                }
                jQuery(".pre").html('');
                $(this).addClass('active');
                var imgPath = $(this).attr('data-img');
                var sku = $(this).attr('data-sku');
                var name = $(this).attr('data-name');
                var description = $(this).attr('data-description');
                var qty = $(this).attr('data-qty');
                jQuery(".donation-box img").attr('src',imgPath);
                jQuery(".description").append('<span> Description: '+description+'</span>');
                jQuery(".qty-needed").append('<span> Quantity Needed: '+qty+'</span>');
                jQuery(".product-name").append('<span> Name: '+name+'</span>');
  		jQuery('.donation-popup-container').css({"display": "block","position": "absolute","width": "100%","height": "100%","background": "#00000030","top": "0px","left": "0","bottom": "0", "right": "0","z-index": "11"});
  	});
  	jQuery(".donation-popup-container-close").click(function(){
  		jQuery('.donation-popup-container').hide();
  	});
  	jQuery(".donate-now").click(function(){
              if(!$(".inactive").length){
                $(".donate-now").addClass('inactive');
                   var sku = $('.active').attr('data-sku');
                   var donatedBy = $("#donation-donated-by").val();
                   var address = $("#donation-address").val()+" "+$("#donation-postcode").val();
                   var donatedType = $("#donation-donated-type").val();
                   var description = $("#donation-description").val();
                   var qty = $("#donation-qty").val();
                   
      	$.ajax({
    	      type: "POST",
    	      url: "https://www.epzmart.com/humanitarian/human/index/donate",
    	      data: {'product_sku':sku,'description':description,'donated_by':donatedBy,'address':address,'donor_type':donatedType,'qty':qty},
    	     success: function(response){
                    $(".donate-now").addClass('inactive');
                    // jQuery(".content-box").hide();
                    jQuery(".donation-box").prepend("<div class='response-msg' style='color:green'>"+response.status+"</div>");
    	               $('body').css('overflow','scroll');
                     setTimeout(function() {
                      jQuery('.donation-popup-container').hide();
                    }, 1000);

                     j
           }
    	    });
      }

	    return false;
 	});
   });
});