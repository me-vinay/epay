/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*browser:true*/
/*global define*/
define(
    [ 
        'Magento_Checkout/js/view/payment/default',
        'jquery', 'ko',
        
    ],
    function (Component, $, ko) {
        'use strict';
       
       
        return Component.extend({
            defaults: {
                template: 'Magento_SamplePaymentGateway/payment/form',
                transactionResult: ''
            },

            initObservable: function () {

                this._super()
                    .observe([
                        'transactionResult'
                    ]);
                return this;
            },

            getCode: function() {
                return 'sample_gateway';
            },

            getData: function() {
                return {
                    'method': this.item.method,
                    'additional_data': {
                        'transaction_result': this.transactionResult()
                    }
                };
            },
            walletLogin: function(event){
                e.preventDefault();
                    console.log("test")
                    var data = {
                        "customerUserId": "string",
                        "password": "string",
                        "vendorUserIdAndAmount": [
                        {
                            "additionalProp1": 0,
                            "additionalProp2": 0,
                            "additionalProp3": 0
                        }
                        ]
                    }
                    $.ajax({
                        type: "POST",
                        url: "https://web.epayerz.com/WalletTransaction/CheckWalletAndUpdateWallet",
                        headers:{
                            'Authorization':'Basic xxxxxxxxxxxxx',
                            'X-CSRF-TOKEN':'xxxxxxxxxxxxxxxxxxxx',
                            'Content-Type':'application/json'
                        },
                        data: data,
                        success: function (data) {
                        console.log(data);
                        }
                    });
            },


            getTransactionResults: function() {
                return _.map(window.checkoutConfig.payment.sample_gateway.transactionResults, function(value, key) {
                    return {
                        'value': key,
                        'transaction_result': value
                    }
                });
            }
        });
    }
);