<?php

namespace Epay\Humanitarian\Block;
/**
  * Copyright © Epayerz, Inc. All rights reserved.
 */
use \Magento\Framework\View\Element\Template;
use \Magento\Framework\View\Element\Template\Context;

class ProList extends Template
{
  
    /**
     * Constructor
     *
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
    }

  
    /**
     * Get action URL 
     *
     * @return string
     */
    public function getDonationformUrl()
    {
           return  $this->getUrl('human/index/donate/', ['_secure' => true]); 
    }
}