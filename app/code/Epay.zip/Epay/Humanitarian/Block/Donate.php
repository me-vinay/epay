<?php
 /**
  * Copyright © Epayerz, Inc. All rights reserved.
 */
namespace Epay\Humanitarian\Block;
use  \Magento\Framework\View\Element\Template\Context;
class Donate extends \Magento\Framework\View\Element\Template
{
    
     /**
     * Donate  Constructor.
     * 
     * @param Context $context
     */
     public function __construct(
          Context $context,
          array $data = []
     ){
          return parent::__construct($context,$data);
     }
 
 }