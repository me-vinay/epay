<?php
/**
  * Copyright © Epayerz, Inc. All rights reserved.
 */
namespace Epay\Humanitarian\Helper;
use Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Store\Model\ScopeInterface;
use \Magento\Store\Model\StoreManagerInterface;
use \Magento\Framework\App\Helper\Context;


class Data extends AbstractHelper
{
    const XML_PATH_ENABLED = 'dbconnection/configure/enable';
    const XML_HOST_PATH = 'dbconnection/configure/hostname';
    const XML_DBNAME_PATH = 'dbconnection/configure/dbname';
    const XML_USERNAME_PATH = 'dbconnection/configure/username';
    const XML_PASSWORD_PATH = 'dbconnection/configure/password';
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * Data constructor.
     * 
     * @param Context $context
     * @param  ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     */

    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        
        $this->scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
    }

    /**
     * get configuration value.
     * 
     * @param string $path 
     * @param int/null $storeId
     * @return string/int 
     */
    public function getConfig($path, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $path,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    
    /**
     *  
     * @return int
     */
    public function isEnabled()
    {
        return $this->getConfig(self::XML_PATH_ENABLED, $this->storeManager->getStore()->getStoreId()); // Pass store id in second parameter
    }
    
    /**
     *  
     * @return string
     */
    public function getHost(){
      return $this->getConfig(self::XML_HOST_PATH, $this->storeManager->getStore()->getStoreId()); // Pass store id in second parameter
    }
    
     /**
     *  
     * @return string
     */
    public function getDbname(){
      return $this->getConfig(self::XML_DBNAME_PATH, $this->storeManager->getStore()->getStoreId()); // Pass store id in second parameter
    }
    
     /**
     *  
     * @return string
     */
    public function getUsername(){
      return $this->getConfig(self::XML_USERNAME_PATH, $this->storeManager->getStore()->getStoreId()); // Pass store id in second parameter
    }
    
     /**
     *  
     * @return string
     */
    public function getPassword(){
      return $this->getConfig(self::XML_PASSWORD_PATH, $this->storeManager->getStore()->getStoreId()); // Pass store id in second parameter
    }

}