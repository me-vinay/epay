<?php

/**
 * Copyright © SV GLobal, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace AndaazFashion\Siteoffer\Model;

use \Magento\Framework\Model\AbstractModel;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Store\Model\StoreManagerInterface;
use \Magento\Directory\Model\Currency;
use \Magento\Framework\Pricing\PriceCurrencyInterface;

class OfferData extends AbstractModel {

    /**
     *
     * @param ScopeConfigInterface $scopeConfig
     */
    private $scopeConfig;

    /**
     *
     * @param StoreManagerInterface $storeManager
     */
    private $storeManager;

    /**
     *
     * @param Currency $currency
     */
    private $currency;

    /**
     *
     * @param PriceCurrencyInterface $priceCurrency
     */
    private $priceCurrency;
    
    /**
     * 
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     * @param Currency $currency
     * @param PriceCurrencyInterface $priceCurrency
     */
    public function __construct(
            ScopeConfigInterface $scopeConfig,
            StoreManagerInterface $storeManager,
            Currency $currency,
            PriceCurrencyInterface $priceCurrency
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_currency = $currency;
        $this->_priceCurrency = $priceCurrency;
    }

    /**
     * Return current store
     * 
     * @return int 
     */
    public function getCurrentStore() {
        return $this->storeManager->getStore();
    }

    /**
     * Return current currency code
     * 
     * @return string 
     */
    public function getCurrentCurrencyCode() {
        return $this->getCurrentStore()->getCurrentCurrencyCode();
    }

    /**
     * Return current currency symbol  
     *
     * @return string
     */
    public function getCurrentCurrencySymbol() {
        return __($this->_priceCurrency->getCurrency()->getCurrencySymbol());
    }
    
    /**
     * Return Module Status
     * 
     * @return int
     */
    public function isEnable(){
        $isEnable = $this->scopeConfig->getValue("siteoffer/topsiteoffer/enable",
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $this->storeManager->getStore()->getStoreId());
        return __($isEnable);
    }

    /**
     * Calculate and return header free shipping offer amount message
     *
     * @return string $shippingOffer
     */
    public function getShippingOffer() {
        $offerPrice = $this->scopeConfig->getValue("siteoffer/topsiteoffer/shipping_offer_amount", \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $this->storeManager->getStore()->getStoreId());
        $curentCurrencyCode = $this->getCurrentStore()
                ->getCurrentCurrency()
                ->getCode();
        $baseCurrencyCode = $this->getCurrentStore()
                ->getBaseCurrency()
                ->getCode();
        //calculate rate if base currency and current currency are different.
        if ($baseCurrencyCode != $curentCurrencyCode) {
            $rate = $this->getCurrentStore()->getCurrentCurrencyRate();
            $offerPrice = $offerPrice * $rate;
        }
        //check if symbol for the current currency available.
        if ($this->getCurrentCurrencySymbol() != '') {
            $offerPrice = $this->getCurrentCurrencySymbol() . '' . $offerPrice;
        } else {
            $offerPrice = $this->getCurrentCurrencyCode() . '' . $offerPrice;
        }
        $shippingOffer = $this->scopeConfig->getValue("siteoffer/topsiteoffer/shipping_offer_text", \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                        $this->storeManager->getStore()->getStoreId()) . ' ' . $offerPrice;
        return __($shippingOffer);
    }

    /**
     * Return header coupon offer message
     *
     * @return string $couponOffer
     */
    public function getCouponOffer() {
        $couponOffer = $this->scopeConfig->getValue("siteoffer/topsiteoffer/coupon_offer_text",
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $this->storeManager->getStore()->getStoreId());
        return __($couponOffer);
    }

}
