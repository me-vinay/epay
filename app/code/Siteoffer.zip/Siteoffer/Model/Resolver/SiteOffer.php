<?php

/**
 * Copyright © SV GLobal, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace AndaazFashion\Siteoffer\Model\Resolver;

use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\GraphQl\Query\Resolver\ValueFactory;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Store\Model\StoreManagerInterface;
use \Magento\Directory\Model\Currency;
use \Magento\Framework\Pricing\PriceCurrencyInterface;
use \AndaazFashion\Siteoffer\Model\OfferData;

class SiteOffer implements ResolverInterface {

    /**
     * @var ValueFactory
     */
    private $valueFactory;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**
     *
     * @param ScopeConfigInterface $scopeConfig
     */
    private $scopeConfig;

    /**
     *
     * @param StoreManagerInterface $storeManager
     */
    private $storeManager;

    /**
     *
     * @param Currency $currency
     */
    private $currency;

    /**
     *
     * @param PriceCurrencyInterface $priceCurrency
     */
    private $priceCurrency;
    
    /**
     * 
     * @param OfferData $offerdata
     */
    private $offerData;
    
    /**
     * 
     * @param ValueFactory $valueFactory
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     * @param Currency $currency
     * @param PriceCurrencyInterface $priceCurrency
     * @param \Psr\Log\LoggerInterface $logger
     * @param OfferData $offerData
     */
    public function __construct(
            ValueFactory $valueFactory,
            ScopeConfigInterface $scopeConfig,
            StoreManagerInterface $storeManager,
            Currency $currency,
            PriceCurrencyInterface $priceCurrency,
            \Psr\Log\LoggerInterface $logger,
            OfferData $offerData
    ) {
        $this->valueFactory = $valueFactory;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_currency = $currency;
        $this->_priceCurrency = $priceCurrency;
        $this->offerData = $offerData;
    }

    /**
     * {@inheritdoc}
     */
    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null) {
        try {
            $data = [];
            $data['status'] = $this->offerData->isEnable();
            $data['shippingoffer'] = $this->offerData->getShippingOffer();
            $data['couponoffer'] = $this->offerData->getCouponOffer();

            $result = function () use ($data) {
                return !empty($data) ? $data : [];
            };
            return $this->valueFactory->create($result);
        } catch (NoSuchEntityException $exception) {
            throw new GraphQlNoSuchEntityException(__($exception->getMessage()));
        } catch (LocalizedException $exception) {
            throw new GraphQlNoSuchEntityException(__($exception->getMessage()));
        }
    }

}
