<?php

/**
 * Copyright © SV GLobal, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace AndaazFashion\Siteoffer\Block;

class SiteOffer extends \Magento\Framework\View\Element\Template {
    
    /**
     * 
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \AndaazFashion\Siteoffer\Model\OfferData $offerData
     * @param array $data
     */
    public function __construct(
            \Magento\Framework\View\Element\Template\Context $context,
            \AndaazFashion\Siteoffer\Model\OfferData $offerData,
            array $data = []
    ) {
        $this->offerData = $offerData;
        parent::__construct($context, $data);
    }
    
     /**
     * Return module status
     *
     * @return int
     */
    public function isEnable(){
         return __($this->offerData->isEnable());
    }

    /**
     * Calculate and return header free shipping offer amount message
     *
     * @return string
     */
    public function getShippingOffer() {
        return __($this->offerData->getShippingOffer());
    }

    /**
     * Return header coupon offer message
     *
     * @return string
     */
    public function getCouponOffer() {
        return __($this->offerData->getCouponOffer());
    }

}
