var config = {
    map: {
        '*': {
            siteoffer: 'AndaazFashion_Siteoffer/js/siteoffer',
        }
    }
};