<?php

namespace Cminds\Marketplace\Model;

class Torate extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('Cminds\Marketplace\Model\ResourceModel\Torate');
    }
}
