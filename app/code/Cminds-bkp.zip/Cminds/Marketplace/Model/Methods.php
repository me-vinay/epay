<?php

namespace Cminds\Marketplace\Model;

class Methods extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('Cminds\Marketplace\Model\ResourceModel\Methods');
    }
}
