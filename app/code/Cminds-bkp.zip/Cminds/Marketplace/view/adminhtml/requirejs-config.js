var config = {
    "map": {
        "*": {
            "mageUtils": "Cminds_Marketplace/js/mage/utils/main"
        }
    }
};