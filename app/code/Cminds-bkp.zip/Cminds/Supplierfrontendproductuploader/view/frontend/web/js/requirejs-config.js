var config = {
    map: {
        '*': {
            wysihtml5: '/js/supplierfrontendproductuploader/wysiwyg/bootstrap-wysihtml5'
        }
    }
};