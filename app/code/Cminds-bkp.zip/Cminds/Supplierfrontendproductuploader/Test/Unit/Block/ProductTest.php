<?php

namespace Cminds\Supplierfrontendproductuploader\Test\Unit\Block;

class ProductTest extends \PHPUnit_Framework_TestCase
{
    protected $_product;

    public function testGetProduct()
    {
        $this->assertTrue(false);
    }
}
