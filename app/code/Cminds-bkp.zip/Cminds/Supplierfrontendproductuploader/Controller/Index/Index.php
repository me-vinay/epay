<?php

namespace Cminds\Supplierfrontendproductuploader\Controller\Index;

use Cminds\Supplierfrontendproductuploader\Controller\AbstractController;

class Index extends AbstractController
{
    protected $_isFrom = false;
}
