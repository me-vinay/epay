<?php

namespace Cminds\Supplierfrontendproductuploader\Controller\Settings;

use Cminds\Supplierfrontendproductuploader\Controller\AbstractController;

class Token extends AbstractController
{
    protected $_isFrom = true;
}
