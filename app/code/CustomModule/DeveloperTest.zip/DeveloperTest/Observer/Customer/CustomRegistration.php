<?php
/**
 * Copyright © neosoft, Inc. All rights reserved.
 * @package Mymodule_DeveloperTest
 */
namespace Mymodule\DeveloperTest\Observer\Customer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use \Magento\Framework\Event\Observer;

use \Magento\Framework\App\Area;


/**
 * Class CustomRegistration
 */
class CustomRegistration implements ObserverInterface
{
    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;


    /**
     * custom customer registration flow constructor
     * 
     * @param CustomerRepositoryInterface $customerRepo
     */

    public function __construct(
      CustomerRepositoryInterface $customerRepository

    ){
      $this->customerRepository = $customerRepository;

    }


    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer){
      $customer = $observer->getEvent()->getCustomer();
      $email = $customer->getEmail();
      $first_name = $customer->getFirstname();
      $last_name = $customer->getLastname();
      $new_fname = str_replace(' ', '', $first_name);
      $modifiedCustomer = $this->customerRepository->getById($customer->getId());
      $modifiedCustomer->setFirstname($new_fname);
      $this->customerRepository->save($modifiedCustomer);
     

      $customerInfo = ['firstname' => $new_fname, 'lastname' => $last_name, 'email' => $email];
      $this->showCustomerLog($customerInfo);
    }

    protected function showCustomerLog($customer){
      $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/customerdata.log');
      $logger = new \Zend\Log\Logger();
      $logger->addWriter($writer);
      $logger->info(print_r($customer,true));
    } 

 
}