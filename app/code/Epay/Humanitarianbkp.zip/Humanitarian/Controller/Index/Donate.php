<?php
 /**
  * Copyright © Epayerz, Inc. All rights reserved.
 */
namespace Epay\HUmanitarian\Controller\Index;
use \Magento\Framework\App\Action\Context;
use \Magento\Framework\View\Result\PageFactory;
use \Magento\Framework\App\Action\Action;
use \Epay\Humanitarian\Model\DonorFactory;
use \Epay\Humanitarian\Model\PickupFactory;
use Magento\Framework\Controller\ResultFactory;
use Epay\Humanitarian\Model\ItemsFactory;

 class Donate extends Action
{
     /**
      * @var PageFactory
      */
     protected $_pageFactory;

     /**
      * 
      * @var type
      */
     private $donorFactory;
     
     /**
      * 
      * @var type
      */
     private $pickupFactory;

     /**
      * @var type
      */
     private $itemFactory;
   
    /**
     * 
     * @param Context $context
     * @param PageFactory $pageFactory
     * @param DonorFactory $donorFactory
     * @param PickupFactory $pickupFactory
     * @param ItemsFactory $itemFactory
     */
     public function __construct(
          Context $context,
          PageFactory $pageFactory,
          DonorFactory $donorFactory,
          PickupFactory $pickupFactory,
          ItemsFactory $itemFactory
     ){
          $this->_pageFactory = $pageFactory;
          $this->donorFactory = $donorFactory;
          $this->pickupFactory = $pickupFactory;
          $this->itemFactory = $itemFactory;
          return parent::__construct($context);
     }
 
     /**
      * Index Donate action.
      * @return Page
      */
     public function execute()
     {  
            $data = (array) $this->getRequest()->getPost();
            if(count($data)){
              $pickup = $this->pickupFactory->create();
              $pickup->setProductSku($data['product_sku']);
              $pickup->setDescription($data['description']);
              $pickup->setDonatedBy($data['donated_by']);
              $pickup->setQty($data['qty']);
              $pickup->setAddress($data['address']);
              $pickup->setStatus('pending');
              $donor = $this->donorFactory->create();
              $donor->setProductSku($data['product_sku']);
              $donor->setDescription($data['description']);
              $donor->setDonatedBy($data['donated_by']);
              $donor->setDonorType($data['donor_type']);
              $donor->setQty($data['qty']);
              $item = $this->itemFactory->create()->load($data['product_id']);
              $updatedQty = ($item->getQty()) - $data['qty'];
              $item->setQty($updatedQty);
              $item->save();
              $donor->save();
              $pickup->save();
              $response = [
                            'status' => 'request recieved'
                        ]; 
            }
            else{
              $response = [
                            'status' => 'request failed'
                        ]; 
            }
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);  //create Json type return object
        $resultJson->setData($response); 
       return $resultJson;
    }    
}