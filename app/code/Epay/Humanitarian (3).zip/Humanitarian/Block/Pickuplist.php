<?php
/**
  * Copyright © Epayerz, Inc. All rights reserved.
 */
namespace Epay\Humanitarian\Block;

use \Magento\Framework\View\Element\Template\Context;
use \Epay\Humanitarian\Model\ResourceModel\Pickup\CollectionFactory;

class Pickuplist extends \Magento\Framework\View\Element\Template
{
    /**
     * 
     * @var type
     */
    private $data;
    
    /**
     * 
     * @var type
     */
    private $pickupCollection;
    
    /**
     * 
     * @param Context $context
     * @param CollectionFactory $pickupCollection
     * @param array $data
     */
    public function __construct(
        Context $context,
        CollectionFactory $pickupCollection,
        array $data = []
    )
    {
        $this->pickupcollection = $pickupCollection;
        parent::__construct($context, $data);
       }
    
    /**
     * 
     * @return type
     */
    public function getPickupCollection() {
        $pickupList = $this->pickupcollection->Create();
        return $pickupList->getdata();
    }
}