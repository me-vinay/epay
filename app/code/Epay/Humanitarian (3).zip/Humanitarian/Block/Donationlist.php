<?php

/**
 * Copyright © Epayerz, Inc. All rights reserved.
 */

namespace Epay\Humanitarian\Block;

use \Magento\Framework\View\Element\Template\Context;
use \Epay\Humanitarian\Model\ResourceModel\Donor\CollectionFactory;

class Donationlist extends \Magento\Framework\View\Element\Template {

    /**
     * 
     * @var type
     */
    private $data;

    /**
     * 
     * @var type
     */
    private $donorCollection;

    /**
     * 
     * @param Context $context
     * @param CollectionFactory $donorCollection
     * @param array $data
     * @return type
     */
    public function __construct(
            Context $context,
            CollectionFactory $donorCollection,
            array $data = []
    ) {
        $this->donorCollection = $donorCollection;
        return parent::__construct($context, $data);
    }
    
    /**
     * 
     * @return type
     */
    public function getDonorCollection() {
        $donorList = $this->donorCollection->Create();
        return $donorList->getdata();
    }

}
