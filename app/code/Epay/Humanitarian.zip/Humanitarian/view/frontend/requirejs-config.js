var config = {
    map: {
        '*': {
            donate: 'Epay_Humanitarian/js/donate'
        }
    }
};