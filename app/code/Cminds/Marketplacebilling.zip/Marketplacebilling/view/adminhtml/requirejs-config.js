var config = {
    "map": {
        "*": {
            "mageUtils": "Cminds_Marketplacebilling/js/mage/utils/main"
        }
    }
};