<?php
namespace Neosoft\Nettelo\Api;

interface BodyMeasurementInterface
{

    /**
     * 
     * @param mixed[] $data
     * @return string
     */
    public function bodyMeasurement($data);
}