<?php
namespace Neosoft\Nettelo\Api;

interface BodyMeasurementInterface
{

    /**
     * 
     * @param mixed[] $ExternalId
     * @return string
     */
    public function bodyMeasurement($ExternalId);
}