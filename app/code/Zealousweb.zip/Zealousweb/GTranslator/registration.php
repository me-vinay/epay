<?php
/**
 * Copyright © 2015 Zealousweb. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Zealousweb_GTranslator',
    __DIR__
);
