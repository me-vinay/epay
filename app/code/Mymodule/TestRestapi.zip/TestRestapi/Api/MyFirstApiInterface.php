<?php


/**
 * File: Mymodule\TestRestapi\Api - MyFirstApiInterface.php
 * Project: Magento
 */

namespace Mymodule\TestRestapi\Api;

interface MyFirstApiInterface
{
  /**
   * Sample Function for Api Demo
   * 
   * @return string
   */
   public function customGetFunction();

   /**
    * Get Param
    *
    * @param string $name
    * @return string
    */
    public function functionWithParam($name);


    /**
    * Get product Id
    *
    * @param int $productId
    * @return \Mymodule\TestRestapi\Api\Data\FirstApiDataInterface
    */
    public function functionPostParam($productId);


}
