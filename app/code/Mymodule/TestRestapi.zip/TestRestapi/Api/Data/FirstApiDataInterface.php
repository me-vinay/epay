<?php


/**
 * File: Mymodule\TestRestapi\Api\Data - FirstApiDataInterface.php
 * Project: Magento
 */

namespace Mymodule\TestRestapi\Api\Data;

interface FirstApiDataInterface {

    /**
     * Get product Name
     * 
     * @return string
     */
    public function getname();

    /**
     * Set product Name 
     * 
     * @param $name
     * @return string
     */
    public function setName($name);

     /**
     *Get product Sku
     *  
     * @return string
     */
    public function getSku();

     /**
     * Set product Sku
     * 
     * @param $sku
     * @return string
     */
    public function setSku($sku);
}