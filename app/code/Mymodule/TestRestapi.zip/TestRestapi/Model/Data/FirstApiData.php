<?php


/**
 * File: Mymodule\TestRestapi\Model\Data - FirstApiData.php
 * Project: Magento
*/

namespace Mymodule\TestRestapi\Model\Data;

class FirstApiData extends \Magento\Framework\Model\AbstractModel implements \Mymodule\TestRestapi\Api\Data\FirstApiDataInterface{

    /**
     * const product name
     */
    const NAME = 'name'; 

    /**
     * const product sku
     */
    const SKU = 'sku';

    /**
     * 
     * @inheritdoc
     */
    public function getName()
    {
       return $this->_getData(self:: NAME);
    }

    /**
     * 
     * @inheritdoc
     */
    public function setName($name)
    {
       return $this->setData(self:: NAME, $name);
    }

    /**
     * 
     * @inheritdoc
     */
    public function getSku()
    {
       return $this->_getData(self:: SKU);
    }

    /**
     * 
     * @inheritdoc
     */
    public function setSku($sku)
    {
       return $this->setData(self:: SKU, $sku);
    }

}