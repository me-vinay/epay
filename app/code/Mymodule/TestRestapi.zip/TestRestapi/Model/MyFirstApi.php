<?php


/**
 * File: Mymodule\TestRestapi\Model - MyFirstApi.php
 * Project: Magento
*/

namespace Mymodule\TestRestapi\Model;
use Magento\Catalog\Model\Product;

class MyFirstApi implements \Mymodule\TestRestapi\Api\MyFirstApiInterface
{

  /**
   * Product Object 
   * @var object product
   */
  protected $product;

  /**
   * My First Api Constructor
   * @param Product $product
   */
  public function __consruct(Product $product)
  {
     $this->product = $product;
  }

  /**
   * @inheritDoc
   * 
  */
   public function customGetFunction(){

    echo "Hi from " .__CLASS__;
    exit;
   }

  /**
   * @inheritDoc
   * 
  */
  public function functionWithParam($name){

    echo "Hi ". $name;
    exit;
   }



   /**
   * @inheritDoc
   * 
   */
  public function functionPostParam($productId){

   return $this->product->load($productId);
   }
}
