<?php
namespace Mymodule\OfflinePayment\Model\Payment;
class Customcashondelivery extends \Magento\Payment\Model\Method\AbstractMethod
{
public $_code = 'offlinepayment';
}