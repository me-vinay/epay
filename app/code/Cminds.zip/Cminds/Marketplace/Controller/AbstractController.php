<?php

namespace Cminds\Marketplace\Controller;

use Cminds\Supplierfrontendproductuploader\Controller\AbstractController as SupplierAbstractController;

class AbstractController extends SupplierAbstractController
{

}
