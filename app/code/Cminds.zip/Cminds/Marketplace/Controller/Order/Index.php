<?php

namespace Cminds\Marketplace\Controller\Order;

use Cminds\Marketplace\Controller\AbstractController;

class Index extends AbstractController
{

}
