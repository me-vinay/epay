<?php

namespace Cminds\Supplierfrontendproductuploader\Controller\Index;

use Cminds\Supplierfrontendproductuploader\Controller\AbstractController;

class Edit extends AbstractController
{
    protected $_isFrom = true;
}
