<?php

namespace Cminds\Supplierfrontendproductuploader\Controller\Sources;

use Cminds\Supplierfrontendproductuploader\Controller\AbstractController;

class SuggestSource extends AbstractController
{

}
