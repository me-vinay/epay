<?php

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Cminds_Supplierfrontendproductuploader',
    __DIR__
);
